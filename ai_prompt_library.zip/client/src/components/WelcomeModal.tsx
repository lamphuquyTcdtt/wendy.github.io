import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { X, Sparkles, Search, Heart, Users, Zap } from "lucide-react";

export default function WelcomeModal() {
  const { isAuthenticated } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    // Kiểm tra xem người dùng đã xem welcome modal chưa
    const hasSeenWelcome = localStorage.getItem("hasSeenWelcome");
    if (!hasSeenWelcome && !isAuthenticated) {
      // Hiển thị sau 1 giây
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isAuthenticated]);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem("hasSeenWelcome", "true");
  };

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      handleClose();
    }
  };

  if (!isOpen) return null;

  const steps = [
    {
      title: "🎨 Chào mừng đến Thư Viện Prompt AI",
      description: "Khám phá hàng ngàn prompt tạo ảnh AI chuyên nghiệp được chia sẻ bởi cộng đồng",
      icon: Sparkles,
      color: "from-accent to-secondary",
    },
    {
      title: "🔍 Tìm Kiếm Prompt Hoàn Hảo",
      description: "Sử dụng thanh tìm kiếm hoặc lọc theo danh mục: Chân dung, Thời trang, Phong cảnh, Ảnh chân thực, Điện ảnh",
      icon: Search,
      color: "from-blue-500 to-cyan-500",
    },
    {
      title: "❤️ Lưu Prompt Yêu Thích",
      description: "Đăng nhập để lưu những prompt yêu thích của bạn và truy cập chúng bất cứ lúc nào",
      icon: Heart,
      color: "from-rose-500 to-pink-500",
    },
    {
      title: "🚀 Chia Sẻ Prompt Của Bạn",
      description: "Tạo tài khoản và đăng những prompt tạo ảnh AI tuyệt vời của bạn để chia sẻ với cộng đồng",
      icon: Zap,
      color: "from-amber-500 to-orange-500",
    },
  ];

  const currentStep = steps[step];
  const CurrentIcon = currentStep.icon;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl shadow-2xl max-w-md w-full border-2 border-border overflow-hidden">
        {/* Header */}
        <div className={`bg-gradient-to-r ${currentStep.color} p-8 text-white relative overflow-hidden`}>
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-40 h-40 rounded-full blur-3xl"></div>
          </div>
          <div className="relative z-10 flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur">
              <CurrentIcon size={24} />
            </div>
            <button
              onClick={handleClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X size={20} />
            </button>
          </div>
          <h2 className="text-2xl font-bold">{currentStep.title}</h2>
        </div>

        {/* Content */}
        <div className="p-8">
          <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
            {currentStep.description}
          </p>

          {/* Step Indicators */}
          <div className="flex gap-2 mb-8">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 flex-1 rounded-full transition-all ${
                  index === step ? "bg-accent" : "bg-border"
                }`}
              />
            ))}
          </div>

          {/* Buttons */}
          <div className="flex gap-3">
            {step > 0 && (
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
                className="flex-1"
              >
                Quay lại
              </Button>
            )}
            <Button
              onClick={handleNext}
              className="flex-1"
            >
              {step === 3 ? "Bắt đầu" : "Tiếp tục"}
            </Button>
          </div>

          {/* Skip Button */}
          <button
            onClick={handleClose}
            className="w-full mt-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Bỏ qua
          </button>
        </div>
      </div>
    </div>
  );
}
