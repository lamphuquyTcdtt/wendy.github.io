import { useState, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, Plus, Heart } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import { ListSkeleton } from "@/components/PromptSkeleton";

const CATEGORIES = [
  { id: "all", label: "Tất cả", icon: "🎨" },
  { id: "portrait", label: "Chân dung", icon: "👤" },
  { id: "fashion", label: "Thời trang", icon: "👗" },
  { id: "landscape", label: "Phong cảnh", icon: "🏞️" },
  { id: "realistic", label: "Ảnh chân thực", icon: "📸" },
  { id: "cinematic", label: "Điện ảnh", icon: "🎬" },
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [offset, setOffset] = useState(0);

  const { data: prompts, isLoading } = trpc.prompt.list.useQuery({
    category: selectedCategory === "all" ? undefined : selectedCategory,
    search: searchQuery || undefined,
    limit: 12,
    offset,
  });

  const { data: favorites } = trpc.favorite.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const favoriteIds = useMemo(
    () => new Set(favorites?.map((f) => f.id) || []),
    [favorites]
  );

  const addFavoriteMutation = trpc.favorite.add.useMutation();
  const removeFavoriteMutation = trpc.favorite.remove.useMutation();

  const handleToggleFavorite = (promptId: number, isFavorited: boolean) => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    if (isFavorited) {
      removeFavoriteMutation.mutate(promptId);
    } else {
      addFavoriteMutation.mutate(promptId);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center gap-2 font-bold text-xl text-gradient">
              <span className="text-2xl">🎨</span>
              AI Prompt Library
            </a>
          </Link>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/my-prompts">
                  <a className="text-sm text-foreground hover:text-accent transition-colors">
                    Prompt của tôi
                  </a>
                </Link>
                <Link href="/favorites">
                  <a className="text-sm text-foreground hover:text-accent transition-colors">
                    Yêu thích
                  </a>
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <a className="text-sm text-foreground hover:text-accent transition-colors">
                      Admin
                    </a>
                  </Link>
                )}
                <Link href="/profile">
                  <a className="text-sm text-foreground hover:text-accent transition-colors">
                    {user?.name || "Hồ sơ"}
                  </a>
                </Link>
                <Button size="sm" variant="outline" onClick={() => window.location.href = getLoginUrl() + "?logout=true"}>
                  Đăng xuất
                </Button>
              </>
            ) : (
              <Button size="sm" asChild>
                <a href={getLoginUrl()}>Đăng nhập</a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section className="gradient-tech py-16 md:py-24 text-white">
        <div className="container">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              Thư Viện Prompt Tạo Ảnh AI Chuyên Nghiệp
            </h1>
            <p className="text-lg md:text-xl mb-8 opacity-90">
              Khám phá hàng ngàn prompt AI được chia sẻ bởi cộng đồng. Tìm kiếm, lưu, và tạo những hình ảnh tuyệt đẹp.
            </p>
            {isAuthenticated ? (
              <Button size="lg" variant="secondary" asChild>
                <Link href="/create-prompt">
                  <a className="flex items-center gap-2">
                    <Plus size={20} />
                    Đăng Prompt Mới
                  </a>
                </Link>
              </Button>
            ) : (
              <Button size="lg" variant="secondary" asChild>
                <a href={getLoginUrl()}>Bắt Đầu Ngay</a>
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Search & Filter Section */}
      <section className="py-8 border-b border-border">
        <div className="container">
          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
              <Input
                placeholder="Tìm kiếm prompt..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setOffset(0);
                }}
                className="pl-10 py-3 text-base"
              />
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  setOffset(0);
                }}
                className={`whitespace-nowrap px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedCategory === cat.id
                    ? "bg-accent text-accent-foreground shadow-md"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                <span className="mr-2">{cat.icon}</span>
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Prompts Grid */}
      <section className="py-12">
        <div className="container">
          {isLoading ? (
            <ListSkeleton count={12} />
          ) : prompts && prompts.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
                {prompts.map((prompt) => (
                  <Link key={prompt.id} href={`/prompt/${prompt.id}`}>
                    <a className="card-tech group cursor-pointer overflow-hidden">
                      {/* Image */}
                      {prompt.imageUrl && (
                        <div className="relative h-48 overflow-hidden bg-muted">
                          <img
                            src={prompt.imageUrl}
                            alt={prompt.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            loading="lazy"
                          />
                        </div>
                      )}

                      {/* Content */}
                      <div className="p-4">
                        {/* Category Badge */}
                        <Badge className="mb-2 capitalize">
                          {prompt.category === "portrait" && "Chân dung"}
                          {prompt.category === "fashion" && "Thời trang"}
                          {prompt.category === "landscape" && "Phong cảnh"}
                          {prompt.category === "realistic" && "Ảnh chân thực"}
                          {prompt.category === "cinematic" && "Điện ảnh"}
                        </Badge>

                        {/* Title */}
                        <h3 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-accent transition-colors">
                          {prompt.title}
                        </h3>

                        {/* Description */}
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {prompt.description || prompt.content.substring(0, 100)}
                        </p>

                        {/* Stats */}
                        <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                          <span>👁️ {prompt.viewCount}</span>
                          <span>❤️ {prompt.favoriteCount}</span>
                        </div>

                        {/* Favorite Button */}
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            handleToggleFavorite(prompt.id, favoriteIds.has(prompt.id));
                          }}
                          className="w-full py-2 rounded-lg border border-border hover:bg-accent hover:text-accent-foreground transition-colors flex items-center justify-center gap-2"
                        >
                          <Heart
                            size={16}
                            className={favoriteIds.has(prompt.id) ? "fill-current" : ""}
                          />
                          {favoriteIds.has(prompt.id) ? "Đã lưu" : "Lưu"}
                        </button>
                      </div>
                    </a>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              <div className="flex justify-center gap-4">
                <Button
                  variant="outline"
                  onClick={() => setOffset(Math.max(0, offset - 12))}
                  disabled={offset === 0}
                >
                  Trang trước
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setOffset(offset + 12)}
                  disabled={!prompts || prompts.length < 12}
                >
                  Trang sau
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-20">
              <p className="text-4xl mb-4">🔍</p>
              <h2 className="text-2xl font-bold mb-2">Không tìm thấy prompt nào</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Hãy thử tìm kiếm từ khác hoặc chọn danh mục khác
              </p>
              {isAuthenticated && (
                <Button size="lg" asChild>
                  <Link href="/create-prompt">
                    <a>Đăng prompt đầu tiên</a>
                  </Link>
                </Button>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 text-gradient">AI Prompt Library</h4>
              <p className="text-sm text-muted-foreground">
                Thư viện prompt tạo ảnh AI chuyên nghiệp cho cộng đồng.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Danh Mục</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent transition-colors">Chân dung</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Thời trang</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Phong cảnh</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Hỗ Trợ</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent transition-colors">Về chúng tôi</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Liên hệ</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Điều khoản</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Cộng Đồng</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent transition-colors">Discord</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Twitter</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">GitHub</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 AI Prompt Library. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
