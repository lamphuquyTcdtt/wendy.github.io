import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Upload, ArrowLeft, X, Image as ImageIcon } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function CreatePrompt() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("portrait");
  const [imageUrl, setImageUrl] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState("");

  const createMutation = trpc.prompt.create.useMutation({
    onSuccess: () => {
      toast.success("Prompt đã được đăng thành công!");
      navigate("/");
    },
    onError: (error) => {
      toast.error(error.message || "Lỗi khi đăng prompt");
    },
  });

  const uploadMutation = trpc.upload.uploadPromptImage.useMutation({
    onSuccess: (data) => {
      setImageUrl(data.url);
      toast.success("Ảnh đã được tải lên");
    },
    onError: (error) => {
      toast.error(error.message || "Lỗi khi tải ảnh");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Vui lòng đăng nhập</h1>
        <p className="text-muted-foreground text-center mb-6">Bạn cần đăng nhập để đăng prompt mới</p>
        <Button size="lg" asChild>
          <a href={getLoginUrl()}>Đăng nhập ngay</a>
        </Button>
      </div>
    );
  }

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Vui lòng chọn một tệp hình ảnh");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Kích thước hình ảnh không được vượt quá 5MB");
      return;
    }

    setImageFile(file);

    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUploadImage = async () => {
    if (!imageFile) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1];
      uploadMutation.mutate({
        filename: imageFile.name,
        base64: base64,
        mimeType: imageFile.type,
      });
    };
    reader.readAsDataURL(imageFile);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error("Vui lòng nhập tiêu đề");
      return;
    }

    if (!content.trim()) {
      toast.error("Vui lòng nhập nội dung prompt");
      return;
    }

    createMutation.mutate({
      title: title.trim(),
      content: content.trim(),
      description: description.trim() || undefined,
      category: category as any,
      imageUrl: imageUrl || undefined,
    });
  };

  const CATEGORIES = [
    { value: "portrait", label: "Chân dung" },
    { value: "fashion", label: "Thời trang" },
    { value: "landscape", label: "Phong cảnh" },
    { value: "realistic", label: "Ảnh chân thực" },
    { value: "cinematic", label: "Điện ảnh" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <Link href="/">
            <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
              <ArrowLeft size={24} />
              <span className="hidden sm:inline font-semibold">Quay lại</span>
            </a>
          </Link>
          <h1 className="text-lg md:text-xl font-bold text-gradient flex-1 text-center px-4">
            Đăng Prompt Mới
          </h1>
          <div className="w-12"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 md:py-8">
        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-6 md:space-y-8">
          {/* Title Field */}
          <div className="space-y-3">
            <Label htmlFor="title" className="text-base md:text-lg font-semibold">
              Tiêu đề Prompt <span className="text-destructive">*</span>
            </Label>
            <Input
              id="title"
              type="text"
              placeholder="Ví dụ: Chân dung phụ nữ xinh đẹp với trang phục truyền thống"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={255}
              className="text-base"
            />
            <p className="text-xs md:text-sm text-muted-foreground">
              {title.length}/255 ký tự
            </p>
          </div>

          {/* Category Field */}
          <div className="space-y-3">
            <Label htmlFor="category" className="text-base md:text-lg font-semibold">
              Danh mục <span className="text-destructive">*</span>
            </Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="text-base h-12 md:h-14">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Description Field */}
          <div className="space-y-3">
            <Label htmlFor="description" className="text-base md:text-lg font-semibold">
              Mô tả ngắn <span className="text-muted-foreground">(Tùy chọn)</span>
            </Label>
            <Textarea
              id="description"
              placeholder="Mô tả ngắn về prompt này để giúp người khác hiểu rõ hơn..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={500}
              rows={3}
              className="text-base resize-none"
            />
            <p className="text-xs md:text-sm text-muted-foreground">
              {description.length}/500 ký tự
            </p>
          </div>

          {/* Content Field */}
          <div className="space-y-3">
            <Label htmlFor="content" className="text-base md:text-lg font-semibold">
              Nội dung Prompt <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="content"
              placeholder="Nhập nội dung prompt đầy đủ tại đây. Ví dụ: A beautiful portrait of a woman with traditional Vietnamese ao dai, soft lighting, professional photography..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={8}
              className="text-base resize-none font-mono"
            />
            <p className="text-xs md:text-sm text-muted-foreground">
              {content.length} ký tự
            </p>
          </div>

          {/* Image Upload */}
          <div className="space-y-3">
            <Label className="text-base md:text-lg font-semibold">
              Ảnh minh họa <span className="text-muted-foreground">(Tùy chọn)</span>
            </Label>

            {imagePreview ? (
              <div className="relative rounded-2xl overflow-hidden bg-muted h-48 md:h-64">
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => {
                    setImagePreview("");
                    setImageFile(null);
                  }}
                  className="absolute top-3 right-3 bg-destructive text-white p-2 rounded-lg hover:bg-destructive/90 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            ) : (
              <label className="border-2 border-dashed border-border rounded-2xl p-6 md:p-8 cursor-pointer hover:border-accent hover:bg-muted/50 transition-colors flex flex-col items-center justify-center text-center">
                <ImageIcon size={40} className="text-muted-foreground mb-3" />
                <p className="font-semibold text-base md:text-lg mb-1">
                  Chọn ảnh minh họa
                </p>
                <p className="text-sm text-muted-foreground mb-4">
                  Kéo thả hoặc nhấp để chọn (Tối đa 5MB)
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </label>
            )}

            {imagePreview && !imageUrl && (
              <Button
                type="button"
                onClick={handleUploadImage}
                disabled={uploadMutation.isPending}
                className="w-full gap-2 text-base h-12 md:h-14"
              >
                {uploadMutation.isPending ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    Đang tải lên...
                  </>
                ) : (
                  <>
                    <Upload size={20} />
                    Tải lên ảnh
                  </>
                )}
              </Button>
            )}

            {imageUrl && (
              <div className="bg-accent/10 border border-accent rounded-xl p-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <ImageIcon size={24} className="text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">Ảnh đã tải lên thành công</p>
                  <p className="text-xs text-muted-foreground truncate">{imageUrl}</p>
                </div>
              </div>
            )}
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-3 pt-6 md:pt-8">
            <Button
              type="button"
              variant="outline"
              className="flex-1 text-base h-12 md:h-14 border-2"
              onClick={() => navigate("/")}
            >
              Hủy
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending}
              className="flex-1 text-base h-12 md:h-14 gap-2"
            >
              {createMutation.isPending ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Đang đăng...
                </>
              ) : (
                "Đăng Prompt"
              )}
            </Button>
          </div>

          {/* Info Card */}
          <Card className="bg-accent/5 border-accent/20 p-4 md:p-6">
            <h4 className="font-semibold text-base mb-3">💡 Mẹo viết prompt tốt</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Mô tả chi tiết về chủ đề, phong cách, ánh sáng</li>
              <li>• Sử dụng từ khóa cụ thể và chi tiết</li>
              <li>• Tránh các từ phủ định, hãy nói cách khác</li>
              <li>• Thêm tham chiếu về nghệ sĩ hoặc phong cách nếu có</li>
              <li>• Kiểm tra lại trước khi đăng</li>
            </ul>
          </Card>
        </form>
      </main>
    </div>
  );
}
