import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Heart, ArrowLeft, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { ListSkeleton } from "@/components/PromptSkeleton";

export default function Favorites() {
  const { isAuthenticated } = useAuth();

  const { data: favorites, isLoading } = trpc.favorite.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const removeMutation = trpc.favorite.remove.useMutation({
    onSuccess: () => {
      toast.success("Đã bỏ lưu prompt");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Vui lòng đăng nhập</h1>
        <p className="text-muted-foreground text-center mb-6">Bạn cần đăng nhập để xem danh sách yêu thích</p>
        <Button size="lg" asChild>
          <a href={getLoginUrl()}>Đăng nhập ngay</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <Link href="/">
            <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
              <ArrowLeft size={24} />
              <span className="hidden sm:inline font-semibold">Quay lại</span>
            </a>
          </Link>
          <h1 className="text-lg md:text-xl font-bold text-gradient flex-1 text-center px-4">
            Prompt Yêu Thích
          </h1>
          <div className="w-12"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 md:py-8">
        {isLoading ? (
          <ListSkeleton count={9} />
        ) : favorites && favorites.length > 0 ? (
          <>
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">Danh sách yêu thích</h2>
                <p className="text-muted-foreground mt-1">{favorites.length} prompt</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {favorites.map((prompt) => (
                <Link key={prompt.id} href={`/prompt/${prompt.id}`}>
                  <a className="card-tech group cursor-pointer overflow-hidden flex flex-col h-full">
                    {/* Image Container */}
                    {prompt.imageUrl && (
                      <div className="relative h-40 md:h-48 overflow-hidden bg-muted">
                        <img
                          src={prompt.imageUrl}
                          alt={prompt.title}
                          className="w-full h-full object-cover group-active:scale-105 md:group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                        />
                      </div>
                    )}

                    {/* Content */}
                    <div className="p-4 md:p-5 flex flex-col flex-1">
                      {/* Category Badge */}
                      <Badge className="mb-3 w-fit text-xs md:text-sm">
                        {prompt.category === "portrait" && "Chân dung"}
                        {prompt.category === "fashion" && "Thời trang"}
                        {prompt.category === "landscape" && "Phong cảnh"}
                        {prompt.category === "realistic" && "Ảnh chân thực"}
                        {prompt.category === "cinematic" && "Điện ảnh"}
                      </Badge>

                      {/* Title */}
                      <h3 className="font-bold text-base md:text-lg mb-2 line-clamp-2 group-active:text-accent md:group-hover:text-accent transition-colors">
                        {prompt.title}
                      </h3>

                      {/* Description */}
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">
                        {prompt.description || prompt.content.substring(0, 100)}
                      </p>

                      {/* Stats */}
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-4 pb-4 border-t border-border">
                        <span className="mt-3">👁️ {prompt.viewCount}</span>
                        <span className="mt-3">❤️ {prompt.favoriteCount}</span>
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          removeMutation.mutate(prompt.id);
                        }}
                        className="w-full py-2.5 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 text-sm md:text-base bg-destructive/10 text-destructive hover:bg-destructive/20 active:bg-destructive/30"
                        disabled={removeMutation.isPending}
                      >
                        <Trash2 size={18} />
                        Bỏ lưu
                      </button>
                    </div>
                  </a>
                </Link>
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-20">
            <p className="text-5xl mb-4">❤️</p>
            <h2 className="text-2xl font-bold mb-2">Chưa có prompt yêu thích</h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Hãy khám phá và lưu những prompt yêu thích của bạn để dễ truy cập sau này
            </p>
            <Button size="lg" asChild>
              <Link href="/">
                <a>Khám phá prompt</a>
              </Link>
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
