import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Plus, Trash2, Edit2, Eye } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { ListSkeleton } from "@/components/PromptSkeleton";

export default function MyPrompts() {
  const { isAuthenticated } = useAuth();

  const { data: prompts, isLoading } = trpc.prompt.myPrompts.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const deleteMutation = trpc.prompt.delete.useMutation({
    onSuccess: () => {
      toast.success("Prompt đã được xóa");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Vui lòng đăng nhập</h1>
        <p className="text-muted-foreground text-center mb-6">Bạn cần đăng nhập để xem prompt của mình</p>
        <Button size="lg" asChild>
          <a href={getLoginUrl()}>Đăng nhập ngay</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <Link href="/">
            <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
              <ArrowLeft size={24} />
              <span className="hidden sm:inline font-semibold">Quay lại</span>
            </a>
          </Link>
          <h1 className="text-lg md:text-xl font-bold text-gradient flex-1 text-center px-4">
            Prompt của tôi
          </h1>
          <Link href="/create-prompt">
            <a className="text-accent hover:opacity-80 transition-opacity p-2 hover:bg-muted rounded-lg">
              <Plus size={24} />
            </a>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 md:py-8">
        {isLoading ? (
          <ListSkeleton count={6} />
        ) : prompts && prompts.length > 0 ? (
          <>
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">Danh sách prompt</h2>
                <p className="text-muted-foreground mt-1">{prompts.length} prompt</p>
              </div>
              <Button size="lg" asChild className="gap-2">
                <Link href="/create-prompt">
                  <a className="flex items-center gap-2">
                    <Plus size={20} />
                    <span className="hidden sm:inline">Tạo mới</span>
                  </a>
                </Link>
              </Button>
            </div>

            <div className="space-y-4">
              {prompts.map((prompt) => (
                <div
                  key={prompt.id}
                  className="card-tech p-4 md:p-6 flex flex-col sm:flex-row gap-4 sm:gap-6 items-start sm:items-center"
                >
                  {/* Image */}
                  {prompt.imageUrl && (
                    <div className="w-full sm:w-24 sm:h-24 md:w-32 md:h-32 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      <img
                        src={prompt.imageUrl}
                        alt={prompt.title}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    </div>
                  )}

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <Badge className="text-xs md:text-sm">
                        {prompt.category === "portrait" && "Chân dung"}
                        {prompt.category === "fashion" && "Thời trang"}
                        {prompt.category === "landscape" && "Phong cảnh"}
                        {prompt.category === "realistic" && "Ảnh chân thực"}
                        {prompt.category === "cinematic" && "Điện ảnh"}
                      </Badge>
                      {prompt.isApproved ? (
                        <Badge className="bg-accent/10 text-accent text-xs md:text-sm">
                          ✓ Đã duyệt
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="text-xs md:text-sm"
                        >
                          ⏳ Chờ duyệt
                        </Badge>
                      )}
                    </div>

                    <h3 className="font-bold text-base md:text-lg mb-2 line-clamp-2">
                      {prompt.title}
                    </h3>

                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                      {prompt.description || prompt.content.substring(0, 100)}
                    </p>

                    <div className="flex items-center gap-4 text-xs md:text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        👁️ {prompt.viewCount}
                      </span>
                      <span className="flex items-center gap-1">
                        ❤️ {prompt.favoriteCount}
                      </span>
                      <span>
                        {new Date(prompt.createdAt).toLocaleDateString("vi-VN")}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 w-full sm:w-auto flex-shrink-0">
                    <Link href={`/prompt/${prompt.id}`}>
                      <a className="flex-1 sm:flex-none p-2.5 rounded-lg border-2 border-border hover:bg-muted transition-colors flex items-center justify-center gap-2 text-sm md:text-base">
                        <Eye size={18} />
                        <span className="hidden sm:inline">Xem</span>
                      </a>
                    </Link>
                    <button
                      onClick={() => deleteMutation.mutate(prompt.id)}
                      disabled={deleteMutation.isPending}
                      className="flex-1 sm:flex-none p-2.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors flex items-center justify-center gap-2 text-sm md:text-base font-medium"
                    >
                      <Trash2 size={18} />
                      <span className="hidden sm:inline">Xóa</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-20">
            <p className="text-5xl mb-4">📝</p>
            <h2 className="text-2xl font-bold mb-2">Chưa có prompt nào</h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Hãy tạo prompt đầu tiên của bạn để chia sẻ với cộng đồng và nhận được phản hồi
            </p>
            <Button size="lg" asChild className="gap-2">
              <Link href="/create-prompt">
                <a className="flex items-center gap-2">
                  <Plus size={20} />
                  Tạo Prompt Mới
                </a>
              </Link>
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
