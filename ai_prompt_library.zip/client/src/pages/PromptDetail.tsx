import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Loader2, Copy, Heart, ArrowLeft, Share2, Download } from "lucide-react";
import { Link, useParams } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { PromptDetailSkeleton } from "@/components/PromptSkeleton";

export default function PromptDetail() {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();
  const [copied, setCopied] = useState(false);

  const promptId = parseInt(id || "0");

  const { data: prompt, isLoading } = trpc.prompt.getById.useQuery(promptId);
  const { data: isFavorited } = trpc.favorite.isFavorited.useQuery(promptId, {
    enabled: isAuthenticated,
  });

  const addFavoriteMutation = trpc.favorite.add.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu prompt");
    },
  });

  const removeFavoriteMutation = trpc.favorite.remove.useMutation({
    onSuccess: () => {
      toast.success("Đã bỏ lưu prompt");
    },
  });

  const handleCopyPrompt = async () => {
    if (!prompt) return;
    try {
      await navigator.clipboard.writeText(prompt.content);
      setCopied(true);
      toast.success("Đã sao chép prompt");
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error("Không thể sao chép");
    }
  };

  const handleToggleFavorite = () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    if (isFavorited) {
      removeFavoriteMutation.mutate(promptId);
    } else {
      addFavoriteMutation.mutate(promptId);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="sticky top-0 z-40 bg-card border-b border-border">
          <div className="container flex items-center justify-between h-16 md:h-20">
            <Link href="/">
              <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
                <ArrowLeft size={24} />
              </a>
            </Link>
          </div>
        </header>
        <main className="container py-6 md:py-8">
          <PromptDetailSkeleton />
        </main>
      </div>
    );
  }

  if (!prompt) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">Prompt không tìm thấy</h1>
        <Link href="/">
          <a className="text-accent hover:underline">Quay lại trang chủ</a>
        </Link>
      </div>
    );
  }

  const categoryLabel = {
    portrait: "Chân dung",
    fashion: "Thời trang",
    landscape: "Phong cảnh",
    realistic: "Ảnh chân thực",
    cinematic: "Điện ảnh",
  } as Record<string, string>;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <Link href="/">
            <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
              <ArrowLeft size={24} />
              <span className="hidden sm:inline font-semibold">Quay lại</span>
            </a>
          </Link>
          <h1 className="text-lg md:text-xl font-bold text-gradient flex-1 text-center px-4 line-clamp-1">
            {prompt.title}
          </h1>
          <div className="w-12"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 md:py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
          {/* Left Column - Image & Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image */}
            {prompt.imageUrl && (
              <div className="rounded-2xl overflow-hidden bg-muted shadow-md">
                <img
                  src={prompt.imageUrl}
                  alt={prompt.title}
                  className="w-full h-auto object-cover"
                  loading="lazy"
                />
              </div>
            )}

            {/* Category & Stats */}
            <div className="flex flex-wrap items-center gap-3 md:gap-4">
              <Badge className="text-sm md:text-base px-4 py-2">
                {categoryLabel[prompt.category as keyof typeof categoryLabel] || prompt.category}
              </Badge>
              <div className="flex gap-4 text-sm md:text-base text-muted-foreground">
                <span className="flex items-center gap-1">
                  👁️ {prompt.viewCount} lượt xem
                </span>
                <span className="flex items-center gap-1">
                  ❤️ {prompt.favoriteCount} yêu thích
                </span>
              </div>
            </div>

            {/* Description */}
            {prompt.description && (
              <div className="bg-card border-2 border-border rounded-2xl p-4 md:p-6">
                <h3 className="font-semibold text-base md:text-lg mb-3">Mô tả</h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {prompt.description}
                </p>
              </div>
            )}

            {/* Prompt Content */}
            <div className="bg-card border-2 border-border rounded-2xl p-4 md:p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-base md:text-lg">Nội dung Prompt</h3>
                <Button
                  size="sm"
                  variant={copied ? "default" : "outline"}
                  onClick={handleCopyPrompt}
                  className="gap-2 text-sm md:text-base"
                >
                  <Copy size={18} />
                  {copied ? "Đã sao chép" : "Sao chép"}
                </Button>
              </div>
              <div className="bg-muted rounded-xl p-4 md:p-5 overflow-x-auto">
                <p className="text-sm md:text-base font-mono text-foreground whitespace-pre-wrap break-words">
                  {prompt.content}
                </p>
              </div>
            </div>

            {/* Author Info */}
            <div className="bg-card border-2 border-border rounded-2xl p-4 md:p-6">
              <h3 className="font-semibold text-base md:text-lg mb-4">Tác giả</h3>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-accent to-secondary flex items-center justify-center text-white font-bold text-lg md:text-xl">
                  {prompt.userId.toString().charAt(0).toUpperCase() || "A"}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-base md:text-lg">Tác giả #{prompt.userId}</p>
                  <p className="text-sm text-muted-foreground">
                    Đăng vào {new Date(prompt.createdAt).toLocaleDateString("vi-VN")}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Actions */}
          <div className="lg:col-span-1 space-y-4">
            {/* Action Buttons */}
            <div className="space-y-3 sticky top-24 md:top-28">
              {/* Favorite Button */}
              <Button
                size="lg"
                onClick={handleToggleFavorite}
                disabled={addFavoriteMutation.isPending || removeFavoriteMutation.isPending}
                className={`w-full gap-2 text-base md:text-lg h-12 md:h-14 ${
                  isFavorited
                    ? "bg-accent text-accent-foreground"
                    : "border-2 border-border text-foreground hover:bg-muted"
                }`}
                variant={isFavorited ? "default" : "outline"}
              >
                <Heart
                  size={20}
                  className={isFavorited ? "fill-current" : ""}
                />
                {isFavorited ? "Đã lưu" : "Lưu prompt"}
              </Button>

              {/* Copy Button - Mobile */}
              <Button
                size="lg"
                onClick={handleCopyPrompt}
                variant="outline"
                className="w-full gap-2 text-base md:text-lg h-12 md:h-14 border-2"
              >
                <Copy size={20} />
                {copied ? "Đã sao chép" : "Sao chép"}
              </Button>

              {/* Share Button */}
              <Button
                size="lg"
                variant="outline"
                className="w-full gap-2 text-base md:text-lg h-12 md:h-14 border-2"
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: prompt.title,
                      text: prompt.description || prompt.content.substring(0, 100),
                      url: window.location.href,
                    });
                  } else {
                    toast.info("Sao chép liên kết để chia sẻ");
                  }
                }}
              >
                <Share2 size={20} />
                Chia sẻ
              </Button>

              {/* Download Button */}
              <Button
                size="lg"
                variant="outline"
                className="w-full gap-2 text-base md:text-lg h-12 md:h-14 border-2"
                onClick={() => {
                  const element = document.createElement("a");
                  element.setAttribute(
                    "href",
                    "data:text/plain;charset=utf-8," + encodeURIComponent(prompt.content || "")
                  );
                  element.setAttribute("download", `${prompt.title}.txt`);
                  element.style.display = "none";
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
                  toast.success("Đã tải xuống prompt");
                }}
              >
                <Download size={20} />
                Tải xuống
              </Button>

              {/* Related Prompts */}
              <Card className="p-4 md:p-6 border-2">
                <h4 className="font-semibold text-base mb-3">Prompt liên quan</h4>
                <p className="text-sm text-muted-foreground">
                  Khám phá thêm prompt trong danh mục "{categoryLabel[prompt.category as keyof typeof categoryLabel] || prompt.category}"
                </p>
                <Link href={`/?category=${prompt.category}`}>
                  <a className="inline-block mt-4 text-accent font-semibold hover:underline">
                    Xem danh mục →
                  </a>
                </Link>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
