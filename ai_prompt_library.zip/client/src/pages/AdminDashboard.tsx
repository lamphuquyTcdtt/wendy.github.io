import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Check, X, BarChart3, Clock } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"pending" | "stats">("pending");
  const [offset, setOffset] = useState(0);

  const { data: stats } = trpc.admin.getStats.useQuery();
  const { data: pendingPrompts, isLoading: loadingPending } = trpc.admin.getPendingPrompts.useQuery(
    { limit: 10, offset }
  );

  const approveMutation = trpc.admin.approvePrompt.useMutation({
    onSuccess: () => {
      toast.success("Prompt đã được duyệt");
    },
  });

  const rejectMutation = trpc.admin.rejectPrompt.useMutation({
    onSuccess: () => {
      toast.success("Prompt đã bị từ chối");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Vui lòng đăng nhập</h1>
        <p className="text-muted-foreground text-center mb-6">Bạn cần đăng nhập để truy cập bảng điều khiển admin</p>
        <Button size="lg" asChild>
          <a href={getLoginUrl()}>Đăng nhập ngay</a>
        </Button>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Không có quyền truy cập</h1>
        <p className="text-muted-foreground text-center mb-6">Chỉ quản trị viên mới có thể truy cập trang này</p>
        <Link href="/">
          <a className="text-accent hover:underline font-semibold">Quay lại trang chủ</a>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <Link href="/">
            <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
              <ArrowLeft size={24} />
              <span className="hidden sm:inline font-semibold">Quay lại</span>
            </a>
          </Link>
          <h1 className="text-lg md:text-xl font-bold text-gradient flex-1 text-center px-4">
            Admin Dashboard
          </h1>
          <div className="w-12"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 md:py-8">
        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-8">
            <Card className="p-4 md:p-6 text-center border-2">
              <div className="text-2xl md:text-3xl font-bold text-accent mb-2">{stats.prompts.total}</div>
              <div className="text-xs md:text-sm text-muted-foreground">Tổng Prompt</div>
            </Card>
            <Card className="p-4 md:p-6 text-center border-2">
              <div className="text-2xl md:text-3xl font-bold text-secondary mb-2">{stats.prompts.approved}</div>
              <div className="text-xs md:text-sm text-muted-foreground">Đã Duyệt</div>
            </Card>
            <Card className="p-4 md:p-6 text-center border-2">
              <div className="text-2xl md:text-3xl font-bold text-destructive mb-2">{stats.prompts.pending}</div>
              <div className="text-xs md:text-sm text-muted-foreground">Chờ Duyệt</div>
            </Card>
            <Card className="p-4 md:p-6 text-center border-2">
              <div className="text-2xl md:text-3xl font-bold text-foreground mb-2">{stats.users.total}</div>
              <div className="text-xs md:text-sm text-muted-foreground">Người Dùng</div>
            </Card>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 md:gap-4 mb-6 border-b border-border overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0">
          <button
            onClick={() => {
              setActiveTab("pending");
              setOffset(0);
            }}
            className={`flex items-center gap-2 px-4 py-3 font-semibold transition-colors whitespace-nowrap text-sm md:text-base ${
              activeTab === "pending"
                ? "text-accent border-b-2 border-accent"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Clock size={18} />
            Chờ Duyệt ({stats?.prompts.pending || 0})
          </button>
          <button
            onClick={() => setActiveTab("stats")}
            className={`flex items-center gap-2 px-4 py-3 font-semibold transition-colors whitespace-nowrap text-sm md:text-base ${
              activeTab === "stats"
                ? "text-accent border-b-2 border-accent"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <BarChart3 size={18} />
            Thống Kê
          </button>
        </div>

        {/* Pending Prompts Tab */}
        {activeTab === "pending" && (
          <div>
            {loadingPending ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="animate-spin text-accent" size={40} />
              </div>
            ) : pendingPrompts && pendingPrompts.length > 0 ? (
              <div className="space-y-4">
                {pendingPrompts.map((prompt) => (
                  <Card key={prompt.id} className="border-2 p-4 md:p-6">
                    <div className="flex flex-col md:flex-row gap-4 md:gap-6 mb-4">
                      {/* Image */}
                      {prompt.imageUrl && (
                        <div className="w-full md:w-24 md:h-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                          <img
                            src={prompt.imageUrl}
                            alt={prompt.title}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        </div>
                      )}

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <h3 className="font-bold text-base md:text-lg">{prompt.title}</h3>
                          <Badge className="text-xs md:text-sm">
                            {prompt.category === "portrait" && "Chân dung"}
                            {prompt.category === "fashion" && "Thời trang"}
                            {prompt.category === "landscape" && "Phong cảnh"}
                            {prompt.category === "realistic" && "Ảnh chân thực"}
                            {prompt.category === "cinematic" && "Điện ảnh"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
                          {prompt.content}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Người dùng #{prompt.userId} • {new Date(prompt.createdAt).toLocaleDateString("vi-VN")}
                        </p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => approveMutation.mutate(prompt.id)}
                        disabled={approveMutation.isPending}
                        className="flex-1 gap-2 text-sm md:text-base h-10 md:h-12"
                      >
                        <Check size={18} />
                        <span className="hidden sm:inline">Duyệt</span>
                      </Button>
                      <Button
                        onClick={() => rejectMutation.mutate(prompt.id)}
                        disabled={rejectMutation.isPending}
                        variant="destructive"
                        className="flex-1 gap-2 text-sm md:text-base h-10 md:h-12"
                      >
                        <X size={18} />
                        <span className="hidden sm:inline">Từ chối</span>
                      </Button>
                    </div>
                  </Card>
                ))}

                {/* Pagination */}
                <div className="flex justify-center gap-3 mt-8">
                  <Button
                    variant="outline"
                    onClick={() => setOffset(Math.max(0, offset - 10))}
                    disabled={offset === 0}
                    className="text-sm md:text-base"
                  >
                    Trang trước
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setOffset(offset + 10)}
                    disabled={!pendingPrompts || pendingPrompts.length < 10}
                    className="text-sm md:text-base"
                  >
                    Trang sau
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-20">
                <p className="text-3xl mb-4">✓</p>
                <p className="text-lg font-semibold mb-2">Không có prompt nào chờ duyệt</p>
                <p className="text-muted-foreground">Tất cả prompt đã được xử lý</p>
              </div>
            )}
          </div>
        )}

        {/* Stats Tab */}
        {activeTab === "stats" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-2 p-6 md:p-8">
              <h3 className="font-bold text-lg md:text-xl mb-6 flex items-center gap-2">
                <BarChart3 size={24} className="text-accent" />
                Thống Kê Prompt
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-muted rounded-lg">
                  <span className="text-muted-foreground font-medium">Tổng số:</span>
                  <span className="font-bold text-lg md:text-xl text-accent">{stats?.prompts.total}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-secondary/10 rounded-lg">
                  <span className="text-muted-foreground font-medium">Đã duyệt:</span>
                  <span className="font-bold text-lg md:text-xl text-secondary">{stats?.prompts.approved}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-destructive/10 rounded-lg">
                  <span className="text-muted-foreground font-medium">Chờ duyệt:</span>
                  <span className="font-bold text-lg md:text-xl text-destructive">{stats?.prompts.pending}</span>
                </div>
              </div>
            </Card>

            <Card className="border-2 p-6 md:p-8">
              <h3 className="font-bold text-lg md:text-xl mb-6 flex items-center gap-2">
                <BarChart3 size={24} className="text-secondary" />
                Thống Kê Người Dùng
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-muted rounded-lg">
                  <span className="text-muted-foreground font-medium">Tổng số:</span>
                  <span className="font-bold text-lg md:text-xl text-foreground">{stats?.users.total}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-accent/10 rounded-lg">
                  <span className="text-muted-foreground font-medium">Quản trị viên:</span>
                  <span className="font-bold text-lg md:text-xl text-accent">{stats?.users.admins}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-muted rounded-lg">
                  <span className="text-muted-foreground font-medium">Người dùng thường:</span>
                  <span className="font-bold text-lg md:text-xl text-foreground">
                    {(stats?.users.total || 0) - (stats?.users.admins || 0)}
                  </span>
                </div>
              </div>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
