import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Loader2, ArrowLeft, LogOut, Mail, Calendar, Shield } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function Profile() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const [name, setName] = useState(user?.name || "");

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      toast.success("Đã đăng xuất");
      logout();
      navigate("/");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Vui lòng đăng nhập</h1>
        <p className="text-muted-foreground text-center mb-6">Bạn cần đăng nhập để xem hồ sơ cá nhân</p>
        <Button size="lg" asChild>
          <a href={getLoginUrl()}>Đăng nhập ngay</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <Link href="/">
            <a className="flex items-center gap-2 text-accent hover:opacity-80 transition-opacity">
              <ArrowLeft size={24} />
              <span className="hidden sm:inline font-semibold">Quay lại</span>
            </a>
          </Link>
          <h1 className="text-lg md:text-xl font-bold text-gradient flex-1 text-center px-4">
            Hồ sơ cá nhân
          </h1>
          <div className="w-12"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6 md:py-8">
        <div className="max-w-2xl mx-auto space-y-6 md:space-y-8">
          {/* Profile Card */}
          <Card className="border-2 p-6 md:p-8">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-8">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-accent to-secondary flex items-center justify-center text-3xl md:text-4xl flex-shrink-0">
                👤
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">{user?.name || "Người dùng"}</h2>
                <p className="text-muted-foreground mb-4">{user?.email}</p>
                {user?.role === "admin" && (
                  <div className="inline-flex items-center gap-2 bg-accent/10 text-accent px-3 py-1.5 rounded-lg text-sm font-medium">
                    <Shield size={16} />
                    Quản trị viên
                  </div>
                )}
              </div>
            </div>

            {/* User Info */}
            <div className="space-y-4 border-t border-border pt-6">
              <div className="flex items-center gap-3">
                <Mail size={20} className="text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium truncate">{user?.email || "Không có"}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Calendar size={20} className="text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Ngày tham gia</p>
                  <p className="font-medium">
                    {user?.createdAt
                      ? new Date(user.createdAt).toLocaleDateString("vi-VN")
                      : "Không có"}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Calendar size={20} className="text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Lần đăng nhập cuối</p>
                  <p className="font-medium">
                    {user?.lastSignedIn
                      ? new Date(user.lastSignedIn).toLocaleDateString("vi-VN")
                      : "Không có"}
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link href="/my-prompts">
              <a className="card-tech p-6 md:p-8 text-center hover:bg-muted transition-colors">
                <p className="text-3xl mb-3">📝</p>
                <h3 className="font-bold text-lg mb-1">Prompt của tôi</h3>
                <p className="text-sm text-muted-foreground">Xem tất cả prompt bạn đã đăng</p>
              </a>
            </Link>

            <Link href="/favorites">
              <a className="card-tech p-6 md:p-8 text-center hover:bg-muted transition-colors">
                <p className="text-3xl mb-3">❤️</p>
                <h3 className="font-bold text-lg mb-1">Yêu thích</h3>
                <p className="text-sm text-muted-foreground">Xem danh sách prompt yêu thích</p>
              </a>
            </Link>
          </div>

          {/* Admin Section */}
          {user?.role === "admin" && (
            <Link href="/admin">
              <a className="card-tech border-accent/30 bg-accent/5 p-6 md:p-8 hover:bg-accent/10 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                    <Shield size={24} className="text-accent" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg">Bảng điều khiển Admin</h3>
                    <p className="text-sm text-muted-foreground">Quản lý prompt và người dùng</p>
                  </div>
                  <span className="text-accent font-semibold">→</span>
                </div>
              </a>
            </Link>
          )}

          {/* Logout Button */}
          <Button
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            variant="outline"
            className="w-full text-base h-12 md:h-14 border-2 border-destructive text-destructive hover:bg-destructive/10 gap-2"
          >
            {logoutMutation.isPending ? (
              <>
                <Loader2 size={20} className="animate-spin" />
                Đang đăng xuất...
              </>
            ) : (
              <>
                <LogOut size={20} />
                Đăng xuất
              </>
            )}
          </Button>

          {/* Info Card */}
          <Card className="bg-accent/5 border-accent/20 p-4 md:p-6">
            <h4 className="font-semibold text-base mb-3">💡 Mẹo</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Bạn có thể xem tất cả prompt bạn đã đăng trong phần "Prompt của tôi"</li>
              <li>• Lưu những prompt yêu thích để dễ tìm kiếm sau này</li>
              <li>• Hồ sơ của bạn được bảo vệ bằng xác thực OAuth an toàn</li>
            </ul>
          </Card>
        </div>
      </main>
    </div>
  );
}
