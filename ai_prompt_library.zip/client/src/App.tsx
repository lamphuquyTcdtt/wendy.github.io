import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import WelcomeModal from "./components/WelcomeModal";
import Home from "./pages/Home";
import PromptDetail from "./pages/PromptDetail";
import CreatePrompt from "./pages/CreatePrompt";
import Favorites from "./pages/Favorites";
import AdminDashboard from "./pages/AdminDashboard";
import Profile from "./pages/Profile";
import MyPrompts from "./pages/MyPrompts";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/prompt/:id"} component={PromptDetail} />
      <Route path={"/create-prompt"} component={CreatePrompt} />
      <Route path={"/favorites"} component={Favorites} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/profile"} component={Profile} />
      <Route path={"/my-prompts"} component={MyPrompts} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <WelcomeModal />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
