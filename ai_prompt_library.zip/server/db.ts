import { eq, and, desc, asc, like, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, prompts, InsertPrompt, Prompt, favorites, notifications, InsertNotification } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== PROMPT FUNCTIONS =====

export async function createPrompt(data: InsertPrompt) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(prompts).values(data);
  return result;
}

export async function getPromptById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(prompts).where(eq(prompts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getApprovedPrompts(
  category?: string,
  search?: string,
  limit: number = 12,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(prompts.isApproved, true)];

  if (category && category !== "all") {
    conditions.push(eq(prompts.category, category as any));
  }

  if (search) {
    conditions.push(like(prompts.title, `%${search}%`));
  }

  const result = await db
    .select()
    .from(prompts)
    .where(and(...conditions))
    .orderBy(desc(prompts.createdAt))
    .limit(limit)
    .offset(offset);

  return result;
}

export async function getPromptsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select()
    .from(prompts)
    .where(eq(prompts.userId, userId))
    .orderBy(desc(prompts.createdAt));

  return result;
}

export async function getPendingPrompts(limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select()
    .from(prompts)
    .where(eq(prompts.isApproved, false))
    .orderBy(asc(prompts.createdAt))
    .limit(limit)
    .offset(offset);

  return result;
}

export async function updatePrompt(id: number, data: Partial<Prompt>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(prompts).set(data).where(eq(prompts.id, id));
  return getPromptById(id);
}

export async function deletePrompt(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.delete(prompts).where(eq(prompts.id, id));
  return true;
}

export async function incrementPromptViewCount(id: number) {
  const db = await getDb();
  if (!db) return;

  const prompt = await getPromptById(id);
  if (prompt) {
    await db.update(prompts).set({ viewCount: prompt.viewCount + 1 }).where(eq(prompts.id, id));
  }
}

// ===== FAVORITE FUNCTIONS =====

export async function addFavorite(userId: number, promptId: number) {
  const db = await getDb();
  if (!db) return false;

  try {
    await db.insert(favorites).values({ userId, promptId });
    
    // Increment favorite count
    const prompt = await getPromptById(promptId);
    if (prompt) {
      await db.update(prompts).set({ favoriteCount: prompt.favoriteCount + 1 }).where(eq(prompts.id, promptId));
    }
    
    return true;
  } catch (error) {
    console.error("Error adding favorite:", error);
    return false;
  }
}

export async function removeFavorite(userId: number, promptId: number) {
  const db = await getDb();
  if (!db) return false;

  try {
    await db.delete(favorites).where(and(eq(favorites.userId, userId), eq(favorites.promptId, promptId)));
    
    // Decrement favorite count
    const prompt = await getPromptById(promptId);
    if (prompt && prompt.favoriteCount > 0) {
      await db.update(prompts).set({ favoriteCount: prompt.favoriteCount - 1 }).where(eq(prompts.id, promptId));
    }
    
    return true;
  } catch (error) {
    console.error("Error removing favorite:", error);
    return false;
  }
}

export async function getUserFavorites(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const favs = await db
    .select({ promptId: favorites.promptId })
    .from(favorites)
    .where(eq(favorites.userId, userId));

  if (favs.length === 0) return [];

  const promptIds = favs.map(f => f.promptId);
  const result = await db
    .select()
    .from(prompts)
    .where(inArray(prompts.id, promptIds))
    .orderBy(desc(prompts.createdAt));

  return result;
}

export async function isFavorited(userId: number, promptId: number) {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(favorites)
    .where(and(eq(favorites.userId, userId), eq(favorites.promptId, promptId)))
    .limit(1);

  return result.length > 0;
}

// ===== NOTIFICATION FUNCTIONS =====

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return false;

  try {
    await db.insert(notifications).values(data);
    return true;
  } catch (error) {
    console.error("Error creating notification:", error);
    return false;
  }
}

export async function getAdminNotifications(limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select()
    .from(notifications)
    .orderBy(desc(notifications.createdAt))
    .limit(limit)
    .offset(offset);

  return result;
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) return false;

  try {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
    return true;
  } catch (error) {
    console.error("Error marking notification as read:", error);
    return false;
  }
}

export async function getPromptStats() {
  const db = await getDb();
  if (!db) return { total: 0, approved: 0, pending: 0 };

  const allPrompts = await db.select().from(prompts);
  const approved = allPrompts.filter(p => p.isApproved).length;
  const pending = allPrompts.filter(p => !p.isApproved).length;

  return {
    total: allPrompts.length,
    approved,
    pending,
  };
}

export async function getUserStats() {
  const db = await getDb();
  if (!db) return { total: 0, admins: 0 };

  const allUsers = await db.select().from(users);
  const admins = allUsers.filter(u => u.role === 'admin').length;

  return {
    total: allUsers.length,
    admins,
  };
}
