import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { storagePut } from "./storage";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ===== PROMPT PROCEDURES =====
  prompt: router({
    // Get all approved prompts with filtering
    list: publicProcedure
      .input(
        z.object({
          category: z.string().optional(),
          search: z.string().optional(),
          limit: z.number().default(12),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        const prompts = await db.getApprovedPrompts(
          input.category,
          input.search,
          input.limit,
          input.offset
        );
        return prompts;
      }),

    // Get single prompt by ID
    getById: publicProcedure
      .input(z.number())
      .query(async ({ input }) => {
        const prompt = await db.getPromptById(input);
        if (!prompt) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Prompt not found" });
        }
        
        // Increment view count
        await db.incrementPromptViewCount(input);
        
        return prompt;
      }),

    // Create new prompt
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1).max(255),
          content: z.string().min(1),
          description: z.string().optional(),
          category: z.enum(["portrait", "fashion", "landscape", "realistic", "cinematic"]),
          imageUrl: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const prompt = await db.createPrompt({
          userId: ctx.user.id,
          title: input.title,
          content: input.content,
          description: input.description,
          category: input.category,
          imageUrl: input.imageUrl,
          isApproved: false,
        });

        // Notify admin about new prompt
        const admin = await db.getUserById(ctx.user.id);
        await notifyOwner({
          title: "Prompt mới cần duyệt",
          content: `Người dùng ${admin?.name || "Ẩn danh"} vừa đăng prompt mới: "${input.title}"`,
        });

        return { success: true };
      }),

    // Update prompt (only by creator or admin)
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          content: z.string().optional(),
          description: z.string().optional(),
          category: z.enum(["portrait", "fashion", "landscape", "realistic", "cinematic"]).optional(),
          imageUrl: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const prompt = await db.getPromptById(input.id);
        if (!prompt) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Prompt not found" });
        }

        if (prompt.userId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to update this prompt" });
        }

        const updated = await db.updatePrompt(input.id, {
          title: input.title || prompt.title,
          content: input.content || prompt.content,
          description: input.description || prompt.description,
          category: input.category || prompt.category,
          imageUrl: input.imageUrl || prompt.imageUrl,
        });

        return updated;
      }),

    // Delete prompt (only by creator or admin)
    delete: protectedProcedure
      .input(z.number())
      .mutation(async ({ input, ctx }) => {
        const prompt = await db.getPromptById(input);
        if (!prompt) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Prompt not found" });
        }

        if (prompt.userId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to delete this prompt" });
        }

        await db.deletePrompt(input);
        return { success: true };
      }),

    // Get user's own prompts
    myPrompts: protectedProcedure.query(async ({ ctx }) => {
      return db.getPromptsByUserId(ctx.user.id);
    }),
  }),

  // ===== FAVORITE PROCEDURES =====
  favorite: router({
    // Add to favorites
    add: protectedProcedure
      .input(z.number())
      .mutation(async ({ input, ctx }) => {
        const success = await db.addFavorite(ctx.user.id, input);
        if (!success) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to add favorite" });
        }
        return { success: true };
      }),

    // Remove from favorites
    remove: protectedProcedure
      .input(z.number())
      .mutation(async ({ input, ctx }) => {
        const success = await db.removeFavorite(ctx.user.id, input);
        if (!success) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to remove favorite" });
        }
        return { success: true };
      }),

    // Get user's favorites
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserFavorites(ctx.user.id);
    }),

    // Check if prompt is favorited
    isFavorited: protectedProcedure
      .input(z.number())
      .query(async ({ input, ctx }) => {
        return db.isFavorited(ctx.user.id, input);
      }),
  }),

  // ===== ADMIN PROCEDURES =====
  admin: router({
    // Get pending prompts for approval
    getPendingPrompts: protectedProcedure
      .input(
        z.object({
          limit: z.number().default(20),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        return db.getPendingPrompts(input.limit, input.offset);
      }),

    // Approve prompt
    approvePrompt: protectedProcedure
      .input(z.number())
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }

        const prompt = await db.getPromptById(input);
        if (!prompt) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Prompt not found" });
        }

        await db.updatePrompt(input, { isApproved: true });
        return { success: true };
      }),

    // Reject prompt
    rejectPrompt: protectedProcedure
      .input(z.number())
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }

        const prompt = await db.getPromptById(input);
        if (!prompt) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Prompt not found" });
        }

        await db.deletePrompt(input);
        return { success: true };
      }),

    // Get statistics
    getStats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      const promptStats = await db.getPromptStats();
      const userStats = await db.getUserStats();

      return {
        prompts: promptStats,
        users: userStats,
      };
    }),

    // Get all users
    getAllUsers: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      // This would need a helper function to get all users
      return [];
    }),
  }),

  // ===== FILE UPLOAD =====
  upload: router({
    // Upload image for prompt
    uploadPromptImage: protectedProcedure
      .input(
        z.object({
          filename: z.string(),
          base64: z.string(),
          mimeType: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const buffer = Buffer.from(input.base64, "base64");
          const fileKey = `prompts/${ctx.user.id}/${Date.now()}-${input.filename}`;

          const { url } = await storagePut(fileKey, buffer, input.mimeType);

          return { success: true, url };
        } catch (error) {
          console.error("Upload error:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Upload failed" });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
