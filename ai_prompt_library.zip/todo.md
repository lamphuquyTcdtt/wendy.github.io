# Thư Viện Prompt Tạo Ảnh AI - Todo List

## Phase 1: Thiết kế Schema & Cấu hình
- [x] Thiết kế schema database (users, prompts, favorites, notifications)
- [x] Push schema migrations với `pnpm db:push`
- [x] Cấu hình biến môi trường
- [x] Tạo helper functions trong server/db.ts

## Phase 2: Trang Chủ & Giao Diện Chính
- [x] Thiết kế global CSS với màu tím-xanh công nghệ
- [x] Xây dựng Navigation Header với logo, menu, nút đăng nhập
- [x] Xây dựng Hero Banner với tiêu đề, mô tả, CTA
- [x] Xây dựng thanh tìm kiếm prompt
- [x] Xây dựng tab danh mục (chân dung, thời trang, phong cảnh, ảnh chân thực, điện ảnh)
- [x] Xây dựng card component cho prompt
- [x] Xây dựng danh sách prompt dạng grid responsive
- [x] Xây dựng pagination/infinite scroll
- [x] Xây dựng Footer

## Phase 3: Hệ Thống Xác Thực & Tài Khoản
- [x] Tích hợp Manus OAuth (Google, Facebook, OTP)
- [x] Xây dựng trang đăng nhập/đăng ký (sử dụng Manus OAuth)
- [x] Xây dựng trang quên mật khẩu
- [x] Xây dựng trang hồ sơ cá nhân (profile)
- [x] Xây dựng chức năng chỉnh sửa hồ sơ
- [x] Xây dựng chức năng đăng xuất
- [x] Tạo procedures tRPC cho auth
- [x] Viết unit tests cho auth

## Phase 4: Trang Đăng Prompt & Chi Tiết Prompt
- [x] Xây dựng trang đăng prompt mới
- [x] Xây dựng form với các trường: tiêu đề, nội dung, ảnh minh họa, danh mục
- [x] Xây dựng upload ảnh minh họa (S3 integration)
- [x] Xây dựng trang chi tiết prompt
- [x] Xây dựng nút copy nhanh prompt
- [x] Xây dựng hiển thị thông tin người đăng
- [x] Xây dựng hiển thị lượt xem & lượt yêu thích
- [x] Tạo procedures tRPC cho prompt CRUD
- [x] Viết unit tests cho prompt

## Phase 5: Chức Năng Yêu Thích
- [x] Xây dựng nút lưu/bỏ lưu prompt yêu thích
- [x] Xây dựng trang danh sách prompt yêu thích
- [x] Xây dựng hiệu ứng animation khi lưu/bỏ lưu
- [x] Tạo procedures tRPC cho favorites
- [x] Viết unit tests cho favorites

## Phase 6: Trang Quản Trị Admin
- [x] Xây dựng Dashboard Admin layout
- [x] Xây dựng trang danh sách prompt cần duyệt
- [x] Xây dựng chức năng duyệt/từ chối prompt
- [x] Xây dựng trang danh sách prompt đã duyệt
- [x] Xây dựng chức năng xóa prompt
- [x] Xây dựng trang quản lý tài khoản người dùng
- [x] Xây dựng trang thống kê (lượt xem, prompt mới, người dùng mới)
- [x] Xây dựng biểu đồ thống kê
- [x] Tạo procedures tRPC cho admin
- [x] Viết unit tests cho admin

## Phase 7: UI/UX, Responsive & Tối Ưu
- [x] Kiểm tra responsive trên mobile (375px, 768px, 1024px, 1440px)
- [x] Thêm hiệu ứng hover mượt cho card
- [x] Thêm hiệu ứng loading skeleton
- [x] Thêm hiệu ứng transition mượt
- [x] Tối ưu hóa SEO (meta tags, structured data, sitemap)
- [x] Tối ưu hóa tốc độ tải (image lazy loading, code splitting)
- [x] Kiểm tra accessibility (WCAG 2.1)
- [x] Kiểm tra cross-browser compatibility
- [x] Thêm toast notifications
- [x] Thêm error handling & empty states

## Phase 8: Thông Báo & Hoàn Thiện
- [x] Xây dựng hệ thống thông báo email cho admin (notifyOwner)
- [x] Xây dựng hệ thống thông báo in-app (notifications table)
- [x] Kiểm tra toàn bộ flow người dùng
- [x] Kiểm tra toàn bộ flow admin
- [ ] Tạo checkpoint cuối cùng
- [ ] Giao kết quả cho người dùng

## Phase 9: Nâng Cấp Giao Diện Mobile Chuyên Nghiệp
- [x] Cập nhật CSS global với typography, spacing, color contrast chuẩn
- [x] Cải thiện header/navigation cho mobile (bottom nav, drawer menu)
- [x] Nâng cấp card component (padding, shadow, border-radius)
- [x] Nâng cấp button component (kích thước, padding, touch target)
- [x] Nâng cấp input field (font size, padding, border)
- [x] Tối ưu hóa font size cho mobile (body, heading, label)
- [x] Cải thiện spacing/margin cho mobile
- [x] Tăng cường color contrast (WCAG AA)
- [x] Cải thiện touch interactions (hover, active states)
- [x] Kiểm tra responsive trên 375px, 480px, 768px
- [x] Kiểm tra toàn bộ flow trên mobile
- [x] Tạo checkpoint nâng cấp mobile


## Phase 10: Nâng Cấp Trải Nghiệm Người Dùng Lần Đầu
- [x] Tạo Welcome Modal chuyên nghiệp
- [x] Tạo Onboarding Tour tương tác
- [x] Nâng cấp Toast Notifications
- [x] Thêm Empty States cho tất cả trang
- [x] Tạo Loading Skeletons
- [x] Thêm Success/Error Messages
- [x] Kiểm tra toàn bộ UX flow
- [ ] Tạo checkpoint nâng cấp UX
